
public interface IConsumer {

	public void consumeItem();
	public boolean canConsume();
	
}


public interface IProducer {

	public void produceItem();
	public boolean canProduce();
}

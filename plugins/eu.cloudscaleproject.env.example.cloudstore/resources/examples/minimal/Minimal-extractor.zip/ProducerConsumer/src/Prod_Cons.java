
public class Prod_Cons {

	public static void main(String[] args) {
		

	}

}

Minimal example 

Author: Jinying Yu

#### Project contents 

- Java Source code (in "input"  folders)
- Run configurations (in "launch" folder)

#### Run
1. Load the project into your workspace via the "New CloudScale Project" wizard; it provides an option to load this example directly
2. Go to the "Extractor/Run" tab in the CloudScale Dashboard and hit the "Run" button

#### Possible configurations 
Play around with options in the "Extractor/Run" tab in the CloudScale Dashboard. Standard configuration is to extract models from the source code.

#### Results
In the "Extractor/Results" tab of the CloudScale Dashboar, you should get a bunch of models.






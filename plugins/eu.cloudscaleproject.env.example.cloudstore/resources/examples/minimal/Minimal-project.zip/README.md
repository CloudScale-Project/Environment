Minimal Example - Project
-------

#### About

#### Project contents


### Compile

```mvn install```

#### Run

```mvn exec:java```

or

```cd dist && ./startApplication.sh```

Minimal Example - Project
-------

#### About

This is a minimal JavaEE servlet project example.
It calculates and displays fibonacci sequence. 

#### Project contents

Project contains only one 'FibonacciServlet' class.

#### Configuration

1. Download Apache Tomcat.
2. In Eclipse right click project folder and select properties.
3. Open 'Java Build Path' and select 'Libraries' tab.
4. Click 'Add Library', select 'Server runtime' and follow the wizard.

#### Run

5. Run project by right clicking it and select 'Run As'->'Run on Server'.
6. Open browser on 'http://localhost:8080/Minimal-Project/' and see the results.


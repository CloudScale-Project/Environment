Minimal example - Dynamic Spotter

Author: Jinying Yu

#### Project contents 

- Java Source code (in "input"  folders)
- Run configurations (in "launch" folder)

#### Run
1. Load the project into your workspace via the "New CloudScale Project" wizard; it provides an option to load this example directly
2. Go to the "Dynamic Spotter/Server" tab in the CloudScale Dashboard, start server and click connect. 
3. Go to the "Dynamic Spotter/Run" tab  and hit the "Run" button

#### Possible configurations 
Play around with options in the "Dynamic Spotter/Run" tab in the CloudScale Dashboard. 

#### Results
In the "Dynamic Spotter/Results" tab of the CloudScale Dashboar, you should get a problem named "OLB".










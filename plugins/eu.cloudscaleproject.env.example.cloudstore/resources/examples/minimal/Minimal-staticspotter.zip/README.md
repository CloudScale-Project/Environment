Minimal example 

Author: Jinying Yu

#### Project contents 

- Java Source code (in "input"  folders)
- Run configurations (in "launch" folder)

#### Run
1. Load the project into your workspace via the "New CloudScale Project" wizard; it provides an option to load this example directly
2. Go to the "Static Spotter/Run" tab in the CloudScale Dashboard and hit the "Run" button

#### Possible configurations 
Play around with options in the "Static Spotter/Run" tab in the CloudScale Dashboard. Standard configuration is to run detection of anti-patterns which are predefined in the pattern catalogue.

#### Results
In the "Static Spotter/Results" tab of the CloudScale Dashboar, you should get a list of annotations which are anti-pattern candidates.









